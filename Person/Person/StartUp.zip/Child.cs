﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    internal class Child:Person
    {
        public Child(string name, int age):base(age,name)
        {
            //if (this.Age > 15) 
            //{
            //    throw new ArgumentException("Child needs to be 15 years old or younger");
            //}
        }
    }
}
