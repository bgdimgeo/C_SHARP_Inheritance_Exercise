﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    internal class Puppy:Dog
    {
        public Puppy():base()
        {

        }
        public void Weep() 
        {
            Console.WriteLine("weeping…");
        }
    }
}
